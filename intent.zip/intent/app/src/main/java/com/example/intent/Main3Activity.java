package com.example.intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
    TextView rev_I,rev_n,rev_nu;
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        rev_I = (TextView)findViewById(R.id.rev_I);
        rev_n=(TextView)findViewById(R.id.rev_n);
        rev_nu=(TextView)findViewById(R.id.rev_Nu);
        b2=findViewById(R.id.Con);
        b1=findViewById(R.id.pre);
        Intent intent= getIntent();
        String str1= intent.getStringExtra("Name");
        String str2=intent.getStringExtra("Id");
        String str3=intent.getStringExtra("Number");
        rev_I.setText("Name :"+str1);
        rev_n.setText("Id :"+str2);
        rev_nu.setText("Number: "+str3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main3Activity.this, "Confirmed", Toast.LENGTH_SHORT).show();
            }
        });


    }
}

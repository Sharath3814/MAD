package com.example.intent;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText Name,Id,Num;
    Button Next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Name=findViewById(R.id.name);
        Id=findViewById(R.id.Id);
        Num=findViewById(R.id.num);
        Next=findViewById(R.id.next);
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String N=Name.getText().toString();
                String I=Id.getText().toString();
                String Nu=Num.getText().toString();
                Intent intent=new Intent(getApplicationContext(),Main3Activity.class);
                intent.putExtra("Name", N);
                intent.putExtra("Id", I);
                intent.putExtra("Number", Nu);
                startActivity(intent);
            }
        });
    }
}
